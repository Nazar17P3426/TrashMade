Diamond.exe by Snare
This is a malware!
DISCLAIMER:
Do NOT run the non-safety version on your real PC, because it will destroy your MBR.
If you don't want to destroy your real PC, run safety version instead.
I'm NOT responsible for ANY damage made to your PC.
If Windows Vista is still slow, try Windows 7.