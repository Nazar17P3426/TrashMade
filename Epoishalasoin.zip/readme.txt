Epoishalasoin.exe by NindowsCahel132 and N17Pro3426
This my medium malware is of some wallpaper Windows 7 penguins
Credits to ArTicZera and wipet for the HSL
Credits to fr4ctalz for the 1st bytebeat, but I modified it
This malware contains flashing lights & earrape, NOT for epilepsy
If you want to run it on Windows XP-11, then use if x86 version or it won't virus!!