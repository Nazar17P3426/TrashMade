X   X EEEEE N    N OOOOO RRRR     A
 X X  E     NN   N O   O R   R   A A
  X   EEEEE N NN N O   O RRRR   A   A
 X X  E     N   NN O   O R  R   AAAAA
X   X EEEEE N    N OOOOO R   R A     A.exe 2.0

Made by: P. ��NG (@Hugopakowashacked)
I made this in C++ and ASM
Icon from Google Chrome

Hi fr4ctalz and N17Pro3426

  #    #

#        #
 ########