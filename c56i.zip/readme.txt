Malware name: c56i.exe
Malware type: GDI trojan
Made in: C++
Made by: Blueno
Works best on: Windows 2000, Windows XP (SP2 or SP3), Windows 7 SP1
Creation date: 05.02.2026
This is very dangerous, it will damage your MBR. Don't run it if you have epilepsy!