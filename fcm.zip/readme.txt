FFFFFF  CCCCCC MM     MM
F      C       M M   M M
FFFFFF C       M  M M  M
F      C       M   M   M
F      C       M       M
F       CCCCCC M       M
by NindowsCahel132

GDI short malware skidders virus RGB some in done :D