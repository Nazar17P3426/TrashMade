------------------------
/Magnifier.exe\
------------------------

Made by Minhgotuknight19

Creation date: March 7 2024
Made in C++
Don't run this on your PC

This is destructive and skidded malware

Also have source before N17Pro3426 can't steal code

-------------------------------------------------------
Magnifier the proxime
-------------------------------------------------------