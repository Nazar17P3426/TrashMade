dxf.exe by NindowsCahel132
This my hard malware is of some computer
Credits to ArTicZera and wipet for the HSL
Credits to fr4ctalz for the 1st bytebeat, but I modified it
This malware contains flashing lights & earrape, NOT for epilepsy
If you want to run it on Windows XP-11, then use if x86 version or it won't virus!!