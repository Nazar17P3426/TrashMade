Kalsium.exe by NindowsCahel132
A short malware developeds 5 payload a few time?
The non-safety version will destructions your PC short any dangerous!
Credits to ArTicZera and wipet for the HSL
Credits to fr4ctalz for the 1st bytebeat, but I modified it
HSL shader RGB lol :)
This malware contains flashing lights & earrape, NOT for epilepsy
If you want to run it on Windows XP-11, then use if Win32 trojan version or it won't virus!!