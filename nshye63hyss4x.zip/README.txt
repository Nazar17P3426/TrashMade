N   N  SSSS Y   Y EEEEE 66666 33333 H   H Y   Y  SSSS  SSSS 4  4 X   X
NN  N S      Y Y  E     6         3 H   H  Y Y  S     S     4  4  X X
N N N  SSS    Y   EEEEE 66666 33333 HHHHH   Y    SSS   SSS  4444   X
N  NN     S   Y   E     6   6     3 H   H   Y       S     S    4  X X
N   N SSSS    Y   EEEEE 66666 33333 H   H   Y   SSSS  SSSS     4 X   X

by NindowsCahel132
GDI C++ know and need in skid

WARNING!
Do not risk, destruction & error
_________________________________________
Thank just been virus on recorded video
Trojan in the Visual Studio 2019/2022