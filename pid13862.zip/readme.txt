pid13862.exe
created by pankick

this dobrota at running pid13862.exe

Ssssss k      iiii ddddd
s          k          d       d
ssssss k      iiii d       d
         s k kk iiii d       d
         s kk    iiii d       d
ssssss k kk iiii ddddd

version 1.0