LOOLOOOOOOOLOLOO!!!
I skidded from Maxi2022gt, meaning this is BAD and SKIDDED malware!