Natenium.exe by Hoang Dat

It has 10 payloads and bytebeats
new RGBQUAD's!
Mythlas shader!
Rate damage: Destructive

Creation date : Janaury 13, 2024

yes, it's skidded

mario MBR!