bool.exe by malsteve527
https://www.youtube.com/@malsteve527

This is a malware.
Run it ONLY in a virtual machine.

I'm NOT responsible for ANY damage!
The safe version has only GDI effects and it will NOT harm your computer.

Let me know about any bugs or problems.
Enjoy!