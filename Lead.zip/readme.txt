L      EEEEEEE  AAAAA  DDDDDD
L      E       A     A D     D
L      EEEEEEE AAAAAAA D     D
L      E       A     A D     D
L      E       A     A D     D
LLLLLL EEEEEEE A     A DDDDDD
by NindowsCahel132

GDI skidder visual problem :{
MBR malware to more guys!!