    eeeeee
   e
  eeeeee
 e
eeeeee scalators.exe

By The Unknown Two and N17Pro38

Rated damage: Destructive

Made in C++

Simple skidded payload!