DDDDDDD   EEEEEEEEE L         EEEEEEEEE TTTTTTTTTTT MM           MM IIIIIII U         U MM           MM
D      D  E         L         E              T      M M         M M    I    U         U M M         M M
D       D E         L         E              T      M  M       M  M    I    U         U M  M       M  M
D       D EEEEEEEEE L         EEEEEEEEE      T      M   M     M   M    I    U         U M   M     M   M
D       D E         L         E              T      M    M   M    M    I    U         U M    M   M    M
D      D  E         L         E              T      M     M M     M    I    U         U M     M M     M
DDDDDDD   EEEEEEEEE LLLLLLLLL EEEEEEEEE      T      M      M      M IIIIIII  UUUUUUUUU  M      M      M

Made by Flippy's World

A skidded 6 payload malware
My new skidded malware

Yes, it's skidded
Damage rate: DESTRUCTIVE and safety