zzz.exe
Made by P. ĐĂNG
WARNING! This malware will destroy your PC!
My YouTube channels:
https://www.youtube.com/channel/UCh5xBsYr8gQzTwcPEZP8nig
https://www.youtube.com/channel/UCgAg64UlUYnbvKGpyStWxWA
It can hide the file, disable Command Prompt and other stuff, overwrite the MBR and shutdown the system.