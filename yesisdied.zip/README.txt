yesisdied.exe by Hugopako
if you reboot your PC, the MBR will die!
Damage rate / type: Destructive