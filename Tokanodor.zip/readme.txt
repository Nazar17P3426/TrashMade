tokanodor.exe by Underwater Banjo

---- made in C++ skidded malware ----

------------warning!----------------

without non-safety run malware getting destroyed your PC!
this is long malware

Creation date: December 13, 2023
by Hugopako