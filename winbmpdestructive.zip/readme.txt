winbmpdestructive.exe 
-----
this flowers you test or happend
OS: Windows XP
by N3ptune