$$\   $$\           $$\ $$\           
$$ |  $$ |          $$ |$$ |          
$$ |  $$ | $$$$$$\  $$ |$$ | $$$$$$\  
$$$$$$$$ |$$  __$$\ $$ |$$ |$$  __$$\ 
$$  __$$ |$$$$$$$$ |$$ |$$ |$$ /  $$ |
$$ |  $$ |$$   ____|$$ |$$ |$$ |  $$ |
$$ |  $$ |\$$$$$$$\ $$ |$$ |\$$$$$$  |
\__|  \__| \_______|\__|\__| \______/

Made by N17Pro38, MSAgentRocks324 and BlakeTheGithu
Credits to GetMBR for Hue function

Works on Windows Vista-11
Made in: C++
Malware type: Trojan
Damage rate: Destructive

The harmful version will destroy your PC, so run it ONLY on a VM.
The harmless version is safe to run on your real PC.