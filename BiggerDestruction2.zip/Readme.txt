###########
BiggerDestruction
###########
Your PC will die after this!
Trojan: Skid
Type: Destructive, I guess
It also overwrite your MBR to make your PC unbootable
If you reboot your PC, then your MBR died.
Don't run on a real machine and run it ONLY on a VM!