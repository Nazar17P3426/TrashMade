#####################
666  InfinityRed  666
#####################

-You can escape from red castle-

WARNING!
This malware is dangerous!
If you run as administrator, it will overwrite the MBR!
If you run NOT as administrator, it will be safe!

Created by P. ĐĂNG
Creation date: 18 May 2024
































Hi fr4ctalz, N17Pro3426 and 2009YCTG, how are you?