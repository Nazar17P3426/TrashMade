﻿██████╗ ██╗      █████╗ ███████╗███╗   ███╗ ██████╗ 
██╔══██╗██║     ██╔══██╗██╔════╝████╗ ████║██╔═══██╗
██████╔╝██║     ███████║███████╗██╔████╔██║██║   ██║
██╔═══╝ ██║     ██╔══██║╚════██║██║╚██╔╝██║██║   ██║
██║     ███████╗██║  ██║███████║██║ ╚═╝ ██║╚██████╔╝
╚═╝     ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ 
This is a remake of a private malware
Don't delete the snds.wav or the epic sound will NOT play
Omg you found so dangerous malware that will never find it again 
Please run this ONLY on a Virtual Machine
This malware can corrupt your MBR and delete the boot file 
Created by: Blueno
My YouTube channel: https://www.youtube.com/channel/UC7o1553riXwGcHit8ElIEmA
Written in: C++
This malware is NOT for people with epilepsy. 
If you have epilepsy, don't run this under any circumstances, because you could end up in the hospital. Seriously!
Have fun by running this malware :D