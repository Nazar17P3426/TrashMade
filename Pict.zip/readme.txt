PPPP  I  CCCC TTTTT
P   P I C       T
PPPP  I C       T
P     I C       T
P     I  CCCC   T
by NindowsCahel132

This short malware GDI MBR image forget in can VGA colors?