This is a skidded malware, not a joke, do NOT run on real PC
created by Rukola and friend