This is a skidded malware, not a joke, do NOT run on real PC

Created by Rukola and friend