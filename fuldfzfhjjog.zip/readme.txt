fuldfzfhjjog.exe 

skidded GDI malware

ssssssss u           u ssssssss
s               u           u s
ssssssss u           u ssssssss
              s u           u               s
ssssssss uuuuuuu ssssssss