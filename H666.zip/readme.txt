H   H  66666   66666   66666
H   H 6       6       6
HHHHH 666666  666666  666666
H   H 6     6 6     6 6     6
H   H  66666   66666   66666
by NindowsCahel132

This GDI done in to?
Skidded shaders malware no problem?