MM     MM  66666   00000        U        U  CCCCCC DDDDDD    11
M M   M M 6       0     0       U        U C       D     D  1 1
M  M M  M 666666  0     0 ----- U        U C       D     D    1
M   M   M 6     6 0     0 ----- U        U C       D     D    1
M       M 6     6 0     0        U      U  C       D     D    1
M       M  66666   00000          UUUUUU    CCCCCC DDDDDD  1111111
by NindowsCahel132

Gdi Extreme Malware Skidders Some In Please Virus Done :D