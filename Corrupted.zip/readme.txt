Corrupted.exe by MazeIcon
---------------------------
My new skidded malware
Rate damage: Destructive