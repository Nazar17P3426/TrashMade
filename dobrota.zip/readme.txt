######  ###### #      #####    ##### ##### ######
#     # #    # #      #   #    #   #   #   #    #
#     # #    # ###### #####    #   #   #   ######
#     # #    # #    # #    #   #   #   #   #    #
######  ###### ###### #     #  #####   #   #    #

by nibel
old version: beta8, beta9, beta9sr1 and 1.0
version 2.0
version or hack afert reboot or that x64, x86
OS: Windows XP