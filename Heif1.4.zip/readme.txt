Heif.exe (1.4) by Snare
WARNING!
Do NOT try this on your main PC, because I'm NOT responsible for ANY damages caused by this malware.
Recommended to run it ONLY on a VM like Windows Sandbox or VMware or VirtualBox.
Works on Windows 7 or newer.