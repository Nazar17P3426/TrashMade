Monocrotophos.exe
by NindowsCahel132 and N17Pro3426
This skidders overwrite boot has QEMU are done!!
:D