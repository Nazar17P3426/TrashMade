Despersium.exe
Made by: Hugopako
Created in: Dev-C++
Skidded? Yes, it's skidded.