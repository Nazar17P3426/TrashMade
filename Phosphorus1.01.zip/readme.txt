Phosphorus.exe (1.01) by Snare
⚠️WARNING⚠️
Do NOT run this on your main PC, because the creator is NOT responsible for ANY damages caused by this malware.
It's recommended to run it ONLY on a VM like Windows Sandbox, VMware or VirtualBox.