 AAAAA  MM     MM MM     MM  OOOOO  N    N I U     U MM     MM
A     A M M   M M M M   M M O     O NN   N I U     U M M   M M
AAAAAAA M  M M  M M  M M  M O     O N N  N I U     U M  M M  M
A     A M   M   M M   M   M O     O N  N N I U     U M   M   M
A     A M       M M       M O     O N   NN I U     U M       M
A     A M       M M       M  OOOOO  N    N I  UUUUU  M       M
by NindowsCahel132

Sorry in see. :>
GDI malware skid.
Has virus to some no problem?
Thanks you,