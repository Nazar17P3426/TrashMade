--xbm.exe--

by Minhgotuknight19

A skidded 8 payload malware
Skidded RGBQUAD, but modified
Mythlas shader!
Damage rate: Destructive

Creation date: February 11 2024
Yes, it's skidded

Kirby MBR