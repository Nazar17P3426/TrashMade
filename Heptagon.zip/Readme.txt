=============
?Heptagon.exe?
=============

Made by Minhgotuknight19

Creation date: April 11 2024
Made in C++
Don't run on your real PC

This is destructive and skidded malware

Credits to GetMBR for the Hue function

-------------------------------------------------------
See the triangles:

Heptagon URL: https://www.twinkl.com.vn/teaching-wiki/heptagon
-------------------------------------------------------

scroll down :)



scroll down :\



scroll down :/



scroll down :|









Hi I am Wynn, yedb0y33k and N17Pro3426