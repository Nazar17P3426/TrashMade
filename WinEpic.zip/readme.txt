WinEpic.exe

by The Unknown Two
GitHub: Hugopako
Discord: Phong Dang
Damage rate: Destructive
Made in C++
Skidded shader payload!