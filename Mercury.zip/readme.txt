Malware name: Mercury
Created by: MazeIcon
Made in: C++ and ASM
Works best in: Windows XP