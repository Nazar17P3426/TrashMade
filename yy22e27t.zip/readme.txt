       - - - - - - -
      -      -      -
     -       -       -
    -                 -      yy22e27t
   -         -         -
 - - - - - - - - - - - -
Trojan is skidded
yy22e27t.exe is no type is garbage messy source
Type: makes mouse go crazy, RGB and credit to people to own it:
cpp, bytebeat, text & more