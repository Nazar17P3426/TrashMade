----------------
EternalYellow.exe
----------------
By Tromiute/Xuepiao

--------- A skidded 10 payload malware ! ---------
my first 2024 skidded malware

HAPPY NEW YEAR!

(Yes, it's skidded)
damage: DESTRUCTIVE