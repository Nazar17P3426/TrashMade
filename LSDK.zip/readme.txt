LSDK.exe by MazeIcon
---------------------------
My first skidded malware
Rate damage: Destructive