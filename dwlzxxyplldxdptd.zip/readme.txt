dwlzxxyplldlldxdptd.exe
--------------------------------
(made by le thy)
--------------------------------
this malware need install msvcr120.dll
OS: Windows XP (yes compilate), Vista, 7, 8, 8.1 (end of life in January 10, 2023), 10 and 11
Creation date: December 17, 2023 (Christmas Eve)
--- for skidders ---
N17pro3426 doesn't stole of name
this is the garbage malware 
GRRRRRRRRRRRRR