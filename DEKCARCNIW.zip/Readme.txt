================
-DEKCARCNIW.exe-
================

Made by Minhgotuknight19

Creation date: March 13 2024
Made in C++
Don't run this on your PC

This is destructive and skidded malware

Also have source before N17Pro3426 can't steal code

-------------------------------------------------------
name means WINCRACKED in reverse
-------------------------------------------------------

scroll down :)



scroll down :\



scroll down :/



scroll down :|









Hi I am Wynn, yedb0y33k and N17Pro3426