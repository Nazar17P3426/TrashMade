Detected.exe by NindowsCahel132
The non-safety version will destructions your PC any dangerous!
This malware contains, NOT for epilepsy
This non-GDI if on, but so system opener idk?
If you want to run it on Windows XP-11, then use if Release x86 version or it won't virus!!