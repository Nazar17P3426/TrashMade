####################################
Skidded trojan: Win32
OS support: Windows XP
Malware name: Anatralier
GDI in C++
lucks lucks lucks
lucks lucks lucks
A skidded virus compation skidded trojan, this is bad malware

          === by Hugopako ===