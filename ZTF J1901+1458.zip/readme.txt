ZTF J1901+1458.exe
                                                                                                                                                         
Malware name: ZTF J1901+1458
Malware type: Trojan
Damage rate: Destructive
Works best on: Windows XP
Made in: C++, ASM
Creator: Hugopako
Creation date: 7 May 2024
This malware is NOT a joke, run it ONLY on a VM, I'm NOT responsible for ANY damages