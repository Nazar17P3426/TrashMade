Malware name: deskt0pdows
Works best in: Windows XP
Made in: C++
Malware type: Trojan
Damage rate: Destructive
Created by: Minhgotuknight19

Credits to GetMBR for Hue function

The safety version is safe to run on a real machine, but the destructive version will disable Task Manager and Command Prompt and corrupt your MBR, run ONLY on a VM.