******      *          *  **""""""
*        **    *          * *          *
*          *   *          *  *"""""""*
*        **    *           * *
******        *******  *           estmolten.exe made by Hugopako
(a.k.a. Hexeclayslone.exe)
 
Warning: This is a skidded malware
My first C++ skidded malware

--- for skidder ---
N17Pro3426 and pankoza isn't skidded garbage malware...

 ##### #   # ### #####  #
#      #  #   #  #    # #
 ####  ###    #  #    # #
     # #  #   #  #    #
#####  #   # ### #####  #