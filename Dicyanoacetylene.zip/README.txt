Dicyanoacetylene by malsteve527
https://www.youtube.com/@malsteve527

This is a malware.
Run it if you know what you're doing!

There may be bugs.
Let me know about any problems in the comments on my YouTube channel.