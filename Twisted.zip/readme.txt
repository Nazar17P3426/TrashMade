Twisted.exe by NindowsCahel132 & LobotomyFireInTheHole1453
A malware developed the course of almost a day
Credits to ArTicZera and wipet for the HSL
Darkness if black light!!!!
This malware contains flashing lights & earrape, NOT for epilepsy