Xythenie.exe
Damage rate: Destructive
Created in: Dev-C++
Made by: P. ��NG
MBR code from: https://github.com/nanochess/invaders

Hi fr4ctalz and N17Pro3426, how are you?