=============
_PCcrazy.exe_
=============

Made by Minhgotuknight19

Creation date: April 18 2024
Made in C++
Don't run this on your PC

This is destructive and skidded malware

Credits To GetMBR For Hue function

-------------------------------------------------------
The PC is crazy & funny
Name Means: PC funny

--------
--------
--------

-------------------------------------------------------

scroll down :)



scroll down :\



scroll down :/



scroll down :|









Hi I am Wynn, yedb0y33k and N17Pro3426