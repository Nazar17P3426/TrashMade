N    N I TTTTT RRRRR   OOOOO  MM     MM EEEEEE TTTTT H    H  AAAA  N    N EEEEEE
NN   N I   T   R    R O     O M M   M M E        T   H    H A    A NN   N E
N N  N I   T   RRRRR  O     O M  M M  M EEEEEE   T   HHHHHH AAAAAA N N  N EEEEEE
N  N N I   T   R  R   O     O M   M   M E        T   H    H A    A N  N N E
N   NN I   T   R   R  O     O M       M E        T   H    H A    A N   NN E
N    N I   T   R    R  OOOOO  M       M EEEEEE   T   H    H A    A N    N EEEEEE
by NindowsCahel132

GDI anti-skidded sorry in no problem, thank yo
bit RGB flash to malware overwrite