Delirium.exe
GDI malware by P. ĐĂNG
My YouTube channels:
https://www.youtube.com/channel/UCh5xBsYr8gQzTwcPEZP8nig
https://www.youtube.com/channel/UCgAg64UlUYnbvKGpyStWxWA