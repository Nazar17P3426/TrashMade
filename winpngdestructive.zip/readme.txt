winpngdestructive.exe 
-----
this flowers you test or happend
work in Windows XP
by Le Thy
Wigofellium.exe MBR again!