Aylum.exe

Malware name: Aylum
Works best in: Windows XP
Made in: C++
Malware type: Trojan
Damage rate: Destructive
Created by: Minhgotuknight19

This skidded trojan is NOT a joke, do you want to run it? I'm NOT respondies to it!