02277.exe 
skidded GDI malware
made in C++
by Hugopako

AMONG ssssssss u           u ssssssss #
            s               u           u s               #
            ssssssss u           u ssssssss #
                          s u           u               s
             ssssssss uuuuuuu ssssssss #