-----------------------------------------------
                   9999692nk
-----------------------------------------------
This malware is skidded
Skid: forever
Compile date: 17/11/2023
Type: It can display message boxes
Credits to C++ users, but Dev-C++ is in the Visual Code 2025