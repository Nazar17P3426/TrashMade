Holder.exe

Made by: P. ��NG (@Hugopakowashacked)
I made this in C++
Damage rate: Destructive
Works best on Windows XP

Hi fr4ctalz and N17Pro3426

  #    #

#        #
 ########