###################
#  DENOWENIW.exe  #
###################

My first C++ skidded malware!
Made by l� Thy
The MBR by nachoess