III X   X L    
 I   X X  L    
 I    X   L    
 I   X X  L    
III X   X LLLL.exe

New skidded trojan by BlakeTheGithu
The harmful version will destroy your PC, so run it ONLY on a VM.
The harmless version is safe to run on your real PC.

No longer requires Visual C++ redistributable (so it now supports Windows 7) and used the better way (omitting CloseHandle instead of a stupid loop) to protect the overwritten MBR.