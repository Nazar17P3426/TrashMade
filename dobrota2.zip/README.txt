dobrota.exe

Created by Nolik777
YouTube: https://www.youtube.com/channel/UC__J0sIW9KvSJowtLJFts7w

The clean version won't kill your system.