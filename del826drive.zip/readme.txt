###########
del826drive
###########

Your PC will die after this
Trojan: it's skidded
Type: Destructive, I guess

it also overwrites your MBR to make your PC unbootable.
If you reboot, then your MBR died.
Don't run on a real machine and run only in VM!