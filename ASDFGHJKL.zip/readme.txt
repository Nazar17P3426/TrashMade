ASDFGHJKL malware

Works fine in: Windows XP 64-bit
Created by: Yedboy33k
It's very skidded

Run this malware only on a VM