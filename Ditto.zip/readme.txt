-DITTO-
gen destruction virus meme

by catsogga
crack
01111110 0111110 01111110
01111110 01111110 10000000

ditti 10000000