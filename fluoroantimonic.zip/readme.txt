++++++++   +         +            +
+                 +         +            +
++++++++   +         +            +
+                 +         +            +   oroantimonic.exe
+                 +          +++++++
+                 +++++

made by Xuepiao (a.k.a Compaq DeskPro2000 or Tromiute)

---- about fluoroantimonic ------
It has skidded 6 payloads and 5 bytebeats 
to chance the icon 
made in C++

---- for skidders ----
but almium MBR
...
maze game MBR
who stop reshacked