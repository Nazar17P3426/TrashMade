BD+20 2457.exe
100% no skidded!

Made by MazeIcon/666MazeIcon666 (@Mázéịcợn)
I made this bad malware in C++!

This is my new skidded malware!

Hi Jeremiah, N17Pro3426, Windows11GDIandTom, pankoza, BlakeTheGithu and more...

:)