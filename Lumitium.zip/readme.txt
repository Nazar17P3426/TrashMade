---------------------------------------------------------------
$$       $$    $$ $$$$$$$$ $$$$ $$$$$$$ $$$$ $$    $$ $$$$$$$$$
$$       $$    $$ $$$$$$$$ $$$$ $$$$$$$ $$$$ $$    $$ $$$$$$$$$
$$       $$    $$ $$ $$ $$        $$         $$    $$ $$ $$  $$
$$       $$    $$ $$ $$ $$  $$    $$     $$  $$    $$ $$ $$  $$
$$$$$$$$ $$$$$$$$ $$ $$ $$  $$    $$     $$  $$$$$$$$ $$ $$  $$
$$$$$$$$ $$$$$$$$ $$ $$ $$  $$    $$     $$  $$$$$$$$ $$ $$  $$
---------------------------------------------------------------
[by UnicoGeniue0999]
--------------------
skidded trojan: Win32
OS support: Windows XP
Requid: vbs to exe 2.0.2 to 3.0.6
Skidded GDI in C++
lucks lucks lucks
lucks lucks lucks
that my friend or virus or by UnicoGeniue0999
the skidded virus compation skidded trojan