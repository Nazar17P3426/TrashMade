█▀▀▄ ▄▀▄ █▀▄ ▄▀▄ █▄░█
█▐█▀ █▀█ █░█ █░█ █░▀█
▀░▀▀ ▀░▀ ▀▀░ ░▀░ ▀░░▀
Made by Snare
I'm NOT responsible for ANY epilepsies!