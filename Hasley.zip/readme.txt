h    h    a     sssss l      ------ Y   Y
h    h  a   a  s      l      -       Y Y
hhhhhh  aaaaa  sssss  l      -----    Y
h    h  a   a       s l      -        Y
h    h  a   a  sssss  llllll ------   Y

Made in C++

Created in January 09, 2024
by Hugopako

Yes, it's skidded
Damage: Destructive