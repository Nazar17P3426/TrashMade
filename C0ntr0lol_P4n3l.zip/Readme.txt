C0ntr0lol_P4n3l.exe

Made by: P. ��NG (@Hugopakowashacked)
I made this in C++ & ASM
Icon from Tamagotchi

Hi fr4ctalz and N17Pro3426

  #    #

#        #
 ########