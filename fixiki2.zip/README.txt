 ###############
    &fixiki&
 ###############
Your PC will die after this
Trojan: Skid
Malware type: Destructive, I guess
Works best in Windows XP and 7
It also overwrites your MBR to make your PC unbootable
If you reboot, then your MBR died.
Don't run it on a real machine and run it ONLY in a VM!