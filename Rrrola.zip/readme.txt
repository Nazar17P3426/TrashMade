RRROLA MALWARE
====================

Skidded? Yes, it's skidded.
Created by: me

Tested on Windows XP/7
=========================

YouTube channel: https://www.youtube.com/channel/UCjy3LhKSqwqNXJBZzpmJ_Ig