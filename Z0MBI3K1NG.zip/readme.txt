Z0MBI3K1NG.exe
Made by Underwater Banjo Extra
(a.k.a. Acid.exe)
 
Warning!
This is a skidded malware
My new skidded malware

For no skidders
N17Pro3426 and pankoza is NOT skidded this garbage malware...

(ULTRA SKID)