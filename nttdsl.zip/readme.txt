this there show is it's
don't run malwares
recover removed malware
nttdsl.exe
firmatted
Windows XP