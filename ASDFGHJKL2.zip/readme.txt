ASDFGHJKL.exe
created by Hugopako

this Thallium at running ASDFGHJKL.exe

Ssssss k      iiii ddddd
s          k          d       d
ssssss k      iiii d       d
         s k kk iiii d       d
         s kk    iiii d       d
ssssss k kk iiii ddddd

BAD MALWARE